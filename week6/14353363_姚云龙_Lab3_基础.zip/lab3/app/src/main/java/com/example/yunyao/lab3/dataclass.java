package com.example.yunyao.lab3;

/**
 * Created by yunyao on 2016/10/12.
 */
    public class dataclass {
        String First_letter;
        String Name;
        String Number;
        String Equipment;
        String Detail;
        String Color;
    }
