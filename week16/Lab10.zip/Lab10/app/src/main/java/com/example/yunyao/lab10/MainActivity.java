package com.example.yunyao.lab10;

import android.app.Activity;
import android.app.Service;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.mapapi.SDKInitializer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity implements SensorEventListener {
    // 定义显示指南针的图片
    ArrowView znzImage;
    TextView angle_value, longitude, latitude, current_position, shake_num, sematic_description;

    // 定义Sensor管理器
    SensorManager mSensorManager;
    Sensor mMagneticSensor, mAccelerometerSensor;

    LocationManager mLocationManager;
    Location mCurrentLocation;
    //震动
    private Vibrator vibrator;
    static int num_shack_num = 0;

    long curTime = 0;
    long lastshakeTime = 0;
    long lastlocateTime = 0;
    String provider;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_main);

        // 获取界面中显示指南针的图片
        znzImage = (ArrowView) findViewById(R.id.angle_pointer);
        angle_value = (TextView) findViewById(R.id.angle_value);
        longitude = (TextView) findViewById(R.id.longitude);
        latitude = (TextView) findViewById(R.id.latitude);
        current_position = (TextView) findViewById(R.id.current_position);
        shake_num = (TextView) findViewById(R.id.shake_num);
        sematic_description = (TextView) findViewById(R.id.sematic_description);

        //震动监听
        vibrator = (Vibrator) getSystemService(Service.VIBRATOR_SERVICE);
        lastshakeTime = System.currentTimeMillis();
        lastlocateTime = lastshakeTime;

        // 获取传感器管理服务
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        mMagneticSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        mAccelerometerSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(true);
        criteria.setPowerRequirement(Criteria.POWER_LOW);

        provider = mLocationManager.getBestProvider(criteria, true);
        Log.i("provider", provider);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "First enable LOCATION ACCESS in settings.", Toast.LENGTH_LONG).show();
            return;
        }
        mCurrentLocation = mLocationManager.getLastKnownLocation(provider);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 为系统的方向传感器注册监听器
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
                SensorManager.SENSOR_DELAY_GAME);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "First enable LOCATION ACCESS in settings.", Toast.LENGTH_LONG).show();
            return;
        }
        mLocationManager.removeUpdates(mLocationListener);
        //加速度传感器
        mSensorManager.registerListener(this,
                mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                //还有SENSOR_DELAY_UI、SENSOR_DELAY_FASTEST、SENSOR_DELAY_GAME等，
                //根据不同应用，需要的反应速率不同，具体根据实际情况设定
                SensorManager.SENSOR_DELAY_NORMAL);
    }


    @Override
    protected void onPause() {
        // 取消注册
        mSensorManager.unregisterListener(this);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "First enable LOCATION ACCESS in settings.", Toast.LENGTH_LONG).show();
            return;
        }
        mLocationManager.requestLocationUpdates(provider, 1000, 1, mLocationListener);
        super.onPause();
    }

    @Override
    protected void onStop() {
        // 取消注册
        mSensorManager.unregisterListener(this);
        super.onStop();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // 获取触发event的传感器类型
        curTime = System.currentTimeMillis();
        int sensorType = event.sensor.getType();
        switch (sensorType) {
            case Sensor.TYPE_ACCELEROMETER :
                if ((curTime-lastshakeTime) > 600) {
                    Log.i("currentTimeMilli_shake", "" + (curTime - lastshakeTime));
                    lastshakeTime = curTime;
                    //values[0]:X轴，values[1]：Y轴，values[2]：Z轴
                    float[] values = event.values;

                    /**
                    *因为一般正常情况下，任意轴数值最大就在9.8~10之间，只有在你突然摇动手机
                    *的时候，瞬时加速度才会突然增大或减少。
                    *所以，经过实际测试，只需监听任一轴的加速度大于14的时候，改变你需要的设置
                    *就OK了~~~
                    */
                    if ((Math.abs(values[0]) > 16 || Math.abs(values[1]) > 16 || Math.abs(values[2]) > 16)) {

                        //摇动手机后，设置button上显示的字为空
                        shake_num.setText(String.format(getString(R.string.shake_text), ++num_shack_num));
                        //摇动手机后，再伴随震动提示~~
                        vibrator.vibrate(100);

                    }
                }
                break;
            case Sensor.TYPE_ORIENTATION:
                // 获取绕Z轴转过的角度。
                znzImage.onUpdateRotation(-event.values[0]);
                angle_value.setText(String.format(getString(R.string.angle_text), znzImage.getCurRotation()));

                if (curTime - lastlocateTime > 3000) {
                    Log.i("currentTimeMilli_change", "" + (curTime-lastlocateTime));
                    lastlocateTime = curTime;
                    if (mCurrentLocation == null) {
                        longitude.setText(String.format(getString(R.string.long_text), 0f));
                        latitude.setText(String.format(getString(R.string.lat_text), 0f));
                    } else {
                        longitude.setText(String.format(getString(R.string.long_text), mCurrentLocation.getLongitude()));
                        latitude.setText(String.format(getString(R.string.lat_text), mCurrentLocation.getLatitude()));

                        new GeoDecoder().execute(mCurrentLocation);
                    }
                }
                break;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
    private LocationListener mLocationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            Log.i("location", "时间："+location.getTime());
            Log.i("location", "经度："+location.getLongitude());
            Log.i("location", "纬度："+location.getLatitude());
            Log.i("location", "海拔："+location.getAltitude());
            mCurrentLocation = location;
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
            Toast.makeText(MainActivity.this, "Enable network provider", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onProviderDisabled(String provider) {
            Toast.makeText(MainActivity.this, "Disable network provider", Toast.LENGTH_SHORT).show();
        }
    };
    private class GeoDecoder extends AsyncTask<Location, Integer, String> {

        @Override
        protected String doInBackground(Location... params) {
            Location param = params[0];
            Log.i("param","经度"+(param==null?"null":param.getLongitude())+"纬度"+(param==null?"null":param.getLatitude()));
            try {
                if (param != null) {
                    //String decode = sendHttpRequest(String.format(getString(R.string.geo_decode), y, x, getString(R.string.server_ak)));
                    String decode = sendHttpRequest(String.format(getString(R.string.geo_decode2), param.getLatitude(), param.getLongitude(), getString(R.string.server_ak)));
                    for(int i = 0; i<decode.split("\"").length; ++i){
                        if (decode.split("\"")[i] == null) break;
                        Log.i("decode_splite_"+i, decode.split("\"")[i]);
                    }

                    Log.i("URL2", String.format(getString(R.string.geo_decode2),
                            param.getLongitude(), param.getLatitude(), getString(R.string.server_ak)));
                    Log.i("decode", decode.split("\"")[13]);
                    return decode.split("\"")[13]+"+"+decode.split("\"")[77];
                }
            } catch (IOException e) {
                //e.printStackTrace();
                Log.i("error", e.getMessage());
            }

            return "Error";
        }

        @Override
        protected void onPostExecute(String s) {
            current_position.setText(s.split("\\+")[0]);
            sematic_description.setText(s.split("\\+")[1]);
        }

        private String sendHttpRequest(String request) throws IOException {
            URL url = new URL(request);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream is = connection.getInputStream();
            Log.i("is_String", is.toString());
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String response = "";
            String readLine;
            while ((readLine = br.readLine()) != null) {
                response = response + readLine;
            }
            Log.i("response", response);
            is.close();
            br.close();
            connection.disconnect();
            return response;
        }
    }
}